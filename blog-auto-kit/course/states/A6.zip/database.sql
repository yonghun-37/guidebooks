BEGIN TRANSACTION;
CREATE TABLE costs (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "costs" VALUES('draft:info:2026-10-27','{
  "date": "2026-10-27",
  "micro_usd": 0,
  "run_id": "draft:info:2026-10-27",
  "settled_at": "2026-10-27",
  "status": "settled"
}
');
INSERT INTO "costs" VALUES('draft:play:2026-10-27','{
  "date": "2026-10-27",
  "micro_usd": 0,
  "run_id": "draft:play:2026-10-27",
  "settled_at": "2026-10-27",
  "status": "settled"
}
');
INSERT INTO "costs" VALUES('draft:affiliate:2026-10-27','{
  "date": "2026-10-27",
  "micro_usd": 0,
  "run_id": "draft:affiliate:2026-10-27",
  "settled_at": "2026-10-27",
  "status": "settled"
}
');
CREATE TABLE links (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE posts (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE runs (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE sponsors (key TEXT PRIMARY KEY, value TEXT NOT NULL);
COMMIT;
