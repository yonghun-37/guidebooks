BEGIN TRANSACTION;
CREATE TABLE costs (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "costs" VALUES('draft:info:2026-10-27','{
  "date": "2026-10-27",
  "micro_usd": 0,
  "run_id": "draft:info:2026-10-27",
  "settled_at": "2026-10-27",
  "status": "settled"
}
');
INSERT INTO "costs" VALUES('draft:play:2026-10-27','{
  "date": "2026-10-27",
  "micro_usd": 0,
  "run_id": "draft:play:2026-10-27",
  "settled_at": "2026-10-27",
  "status": "settled"
}
');
INSERT INTO "costs" VALUES('draft:affiliate:2026-10-27','{
  "date": "2026-10-27",
  "micro_usd": 0,
  "run_id": "draft:affiliate:2026-10-27",
  "settled_at": "2026-10-27",
  "status": "settled"
}
');
CREATE TABLE links (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "links" VALUES('nail','{
  "check": "mock 정상",
  "checked_on": "2026-10-27",
  "id": "nail",
  "price": "표시하지 않음",
  "program": "쿠팡(모의)",
  "url": "https://example.invalid/nail"
}
');
CREATE TABLE posts (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "posts" VALUES('info','{
  "approval": {
    "date": "2026-10-27",
    "hash": "51f274513fb899e9461d3ad10c53e3e82f476fd438d07121396d8c10e2dd4e4b",
    "reviewed_rules": [],
    "reviewer": "서윤"
  },
  "auto_allowed_types": [],
  "content_hash": "dd337ce63aec07335241de59785d8f0a00b587e7a84aa79e78d41315f9b2c519",
  "daily_limit": 2,
  "date": "2026-10-27",
  "destination": "mock",
  "doc": {
    "as_of": "2026-10-27",
    "author": "서윤(가상)",
    "commercial_relations": [],
    "comparison_only": false,
    "content_id": "info",
    "content_type": "info",
    "contract": {
      "ai_allowed": true
    },
    "description": "정부 지원을 확인하는 순서",
    "emergency_topics": [],
    "experience": "",
    "experience_by": "",
    "html": "<p>2026년 10월 조사 기준. 부모급여와 아동수당은 신청 대상과 절차를 각각 확인해야 합니다.</p>\n<h2>부모급여와 아동수당</h2>\n<p>부모급여는 0~11개월 월 100만원, 12~23개월 월 50만원입니다. [N037]</p>\n<p>아동수당은 9세 미만, 기본 월 10만원입니다. [N038] 지역별 추가 지급과 개인별 신청 조건은 확인하세요.</p>\n<h2>신청 전에 확인할 것</h2>\n<p>어린이집을 이용하면 부모급여의 지급 방식과 차액이 달라질 수 있습니다. 복지로와 거주지 담당 기관에서 현재 대상과 신청 방법을 확인하세요.</p>\n<p>출처: [N037] 보건복지부 부모급여 안내, [N038] 보건복지부 아동수당 안내.</p>",
    "markdown": "2026년 10월 조사 기준. 부모급여와 아동수당은 신청 대상과 절차를 각각 확인해야 합니다.\n\n## 부모급여와 아동수당\n\n부모급여는 0~11개월 월 100만원, 12~23개월 월 50만원입니다. [N037]\n\n아동수당은 9세 미만, 기본 월 10만원입니다. [N038] 지역별 추가 지급과 개인별 신청 조건은 확인하세요.\n\n## 신청 전에 확인할 것\n\n어린이집을 이용하면 부모급여의 지급 방식과 차액이 달라질 수 있습니다. 복지로와 거주지 담당 기관에서 현재 대상과 신청 방법을 확인하세요.\n\n출처: [N037] 보건복지부 부모급여 안내, [N038] 보건복지부 아동수당 안내.\n",
    "media": [
      {
        "alt": "가상 그림책꽂이 그림",
        "child_photo": false,
        "kind": "illustration",
        "path": "samples/books.png",
        "permissions": "직접 제작"
      }
    ],
    "photos": [],
    "product_records": [],
    "risk_flags": [],
    "source_notes": [
      {
        "age_range": "0~3세",
        "checked_on": "2026-10-27",
        "claims": [
          "부모급여는 0~11개월 월 100만원, 12~23개월 월 50만원입니다."
        ],
        "country": "KR",
        "id": "N037",
        "license": "원문 링크 및 이용 조건 확인",
        "official": true,
        "url": "https://www.korea.kr/news/policyNewsView.do?newsId=148957936"
      },
      {
        "age_range": "0~3세",
        "checked_on": "2026-10-27",
        "claims": [
          "아동수당은 9세 미만, 기본 월 10만원입니다."
        ],
        "country": "KR",
        "id": "N038",
        "license": "원문 링크 및 이용 조건 확인",
        "official": true,
        "url": "https://www.korea.kr/news/policyNewsView.do?newsId=148963373"
      }
    ],
    "title": "2026 부모급여·아동수당 한 번에 정리"
  },
  "draft_hash": "d724f73bd67e0cc3a928fc68be551b0232e91e9c81018825f0be4fb80fd2ad55",
  "id": "info",
  "is_update": true,
  "post_id": 1,
  "prepared": {
    "categories": [
      1
    ],
    "destination": "mock",
    "media": [
      1
    ],
    "media_hashes": {
      "1": "746a27c05dab0e1bb948af77314adabc546ab1a3b5171169a1eae0ecd44dcf35"
    },
    "tags": [
      1
    ]
  },
  "server_checked": true,
  "server_date": "2026-10-28T09:00:00",
  "server_history": [
    "future",
    "publish"
  ],
  "server_new_confirmed": false,
  "slug": "bx-info",
  "snapshot": {
    "categories": [
      1
    ],
    "content": "<p>2026년 10월 조사 기준. 부모급여와 아동수당은 신청 대상과 절차를 각각 확인해야 합니다.</p>\n<h2>부모급여와 아동수당</h2>\n<p>부모급여는 0~11개월 월 100만원, 12~23개월 월 50만원입니다. [N037]</p>\n<p>아동수당은 9세 미만, 기본 월 10만원입니다. [N038] 지역별 추가 지급과 개인별 신청 조건은 확인하세요.</p>\n<h2>신청 전에 확인할 것</h2>\n<p>어린이집을 이용하면 부모급여의 지급 방식과 차액이 달라질 수 있습니다. 복지로와 거주지 담당 기관에서 현재 대상과 신청 방법을 확인하세요.</p>\n<p>출처: [N037] 보건복지부 부모급여 안내, [N038] 보건복지부 아동수당 안내.</p>",
    "excerpt": "정부 지원을 확인하는 순서",
    "featured_media": 1,
    "slug": "bx-info",
    "status": "draft",
    "tags": [
      1
    ],
    "title": "2026 부모급여·아동수당 한 번에 정리"
  },
  "status": "publish",
  "url": "http://mock.local/?p=1"
}
');
CREATE TABLE runs (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "runs" VALUES('create:mock:info','{
  "id": "create:mock:info",
  "post_id": 1,
  "state": "done"
}
');
INSERT INTO "runs" VALUES('content:mock:dd337ce63aec07335241de59785d8f0a00b587e7a84aa79e78d41315f9b2c519','{
  "id": "content:mock:dd337ce63aec07335241de59785d8f0a00b587e7a84aa79e78d41315f9b2c519",
  "owner": "info"
}
');
INSERT INTO "runs" VALUES('quota:mock:2026-10-27:info','{
  "date": "2026-10-27",
  "id": "quota:mock:2026-10-27:info",
  "state": "reserved"
}
');
INSERT INTO "runs" VALUES('schedule:mock:1:51f274513fb899e9461d3ad10c53e3e82f476fd438d07121396d8c10e2dd4e4b','{
  "id": "schedule:mock:1:51f274513fb899e9461d3ad10c53e3e82f476fd438d07121396d8c10e2dd4e4b",
  "state": "sending"
}
');
CREATE TABLE sponsors (key TEXT PRIMARY KEY, value TEXT NOT NULL);
COMMIT;
