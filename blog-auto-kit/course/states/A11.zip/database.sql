BEGIN TRANSACTION;
CREATE TABLE costs (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "costs" VALUES('draft:info:2026-10-27','{
  "date": "2026-10-27",
  "micro_usd": 0,
  "run_id": "draft:info:2026-10-27",
  "settled_at": "2026-10-27",
  "status": "settled"
}
');
INSERT INTO "costs" VALUES('draft:play:2026-10-27','{
  "date": "2026-10-27",
  "micro_usd": 0,
  "run_id": "draft:play:2026-10-27",
  "settled_at": "2026-10-27",
  "status": "settled"
}
');
INSERT INTO "costs" VALUES('draft:affiliate:2026-10-27','{
  "date": "2026-10-27",
  "micro_usd": 0,
  "run_id": "draft:affiliate:2026-10-27",
  "settled_at": "2026-10-27",
  "status": "settled"
}
');
CREATE TABLE links (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "links" VALUES('nail','{
  "check": "mock 정상",
  "checked_on": "2026-10-27",
  "id": "nail",
  "price": "표시하지 않음",
  "program": "쿠팡(모의)",
  "url": "https://example.invalid/nail"
}
');
CREATE TABLE posts (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "posts" VALUES('info','{
  "approval": {
    "date": "2026-10-27",
    "hash": "51f274513fb899e9461d3ad10c53e3e82f476fd438d07121396d8c10e2dd4e4b",
    "reviewed_rules": [
      "automation.T1"
    ],
    "reviewer": "서윤"
  },
  "auto_allowed_types": [
    "info",
    "play"
  ],
  "config_path": null,
  "content_hash": "dd337ce63aec07335241de59785d8f0a00b587e7a84aa79e78d41315f9b2c519",
  "daily_limit": 2,
  "date": "2026-10-27",
  "destination": "mock",
  "doc": {
    "as_of": "2026-10-27",
    "author": "서윤(가상)",
    "commercial_relations": [],
    "comparison_only": false,
    "content_id": "info",
    "content_type": "info",
    "contract": {
      "ai_allowed": true
    },
    "description": "정부 지원을 확인하는 순서",
    "emergency_topics": [],
    "experience": "",
    "experience_by": "",
    "html": "<p>2026년 10월 조사 기준. 부모급여와 아동수당은 신청 대상과 절차를 각각 확인해야 합니다.</p>\n<h2>부모급여와 아동수당</h2>\n<p>부모급여는 0~11개월 월 100만원, 12~23개월 월 50만원입니다. [N037]</p>\n<p>아동수당은 9세 미만, 기본 월 10만원입니다. [N038] 지역별 추가 지급과 개인별 신청 조건은 확인하세요.</p>\n<h2>신청 전에 확인할 것</h2>\n<p>어린이집을 이용하면 부모급여의 지급 방식과 차액이 달라질 수 있습니다. 복지로와 거주지 담당 기관에서 현재 대상과 신청 방법을 확인하세요.</p>\n<p>출처: [N037] 보건복지부 부모급여 안내, [N038] 보건복지부 아동수당 안내.</p>",
    "markdown": "2026년 10월 조사 기준. 부모급여와 아동수당은 신청 대상과 절차를 각각 확인해야 합니다.\n\n## 부모급여와 아동수당\n\n부모급여는 0~11개월 월 100만원, 12~23개월 월 50만원입니다. [N037]\n\n아동수당은 9세 미만, 기본 월 10만원입니다. [N038] 지역별 추가 지급과 개인별 신청 조건은 확인하세요.\n\n## 신청 전에 확인할 것\n\n어린이집을 이용하면 부모급여의 지급 방식과 차액이 달라질 수 있습니다. 복지로와 거주지 담당 기관에서 현재 대상과 신청 방법을 확인하세요.\n\n출처: [N037] 보건복지부 부모급여 안내, [N038] 보건복지부 아동수당 안내.\n",
    "media": [
      {
        "alt": "가상 그림책꽂이 그림",
        "child_photo": false,
        "kind": "illustration",
        "path": "samples/books.png",
        "permissions": "직접 제작"
      }
    ],
    "photos": [],
    "product_records": [],
    "risk_flags": [],
    "source_notes": [
      {
        "age_range": "0~3세",
        "checked_on": "2026-10-27",
        "claims": [
          "부모급여는 0~11개월 월 100만원, 12~23개월 월 50만원입니다."
        ],
        "country": "KR",
        "id": "N037",
        "license": "원문 링크 및 이용 조건 확인",
        "official": true,
        "url": "https://www.korea.kr/news/policyNewsView.do?newsId=148957936"
      },
      {
        "age_range": "0~3세",
        "checked_on": "2026-10-27",
        "claims": [
          "아동수당은 9세 미만, 기본 월 10만원입니다."
        ],
        "country": "KR",
        "id": "N038",
        "license": "원문 링크 및 이용 조건 확인",
        "official": true,
        "url": "https://www.korea.kr/news/policyNewsView.do?newsId=148963373"
      }
    ],
    "title": "2026 부모급여·아동수당 한 번에 정리"
  },
  "draft_hash": "d724f73bd67e0cc3a928fc68be551b0232e91e9c81018825f0be4fb80fd2ad55",
  "id": "info",
  "is_update": true,
  "post_id": 1,
  "prepared": {
    "categories": [
      1
    ],
    "destination": "mock",
    "media": [
      1
    ],
    "media_hashes": {
      "1": "746a27c05dab0e1bb948af77314adabc546ab1a3b5171169a1eae0ecd44dcf35"
    },
    "tags": [
      1
    ]
  },
  "server_checked": true,
  "server_date": "2026-10-28T09:00:00",
  "server_history": [
    "draft",
    "future",
    "publish"
  ],
  "server_new_confirmed": false,
  "slug": "bx-info",
  "snapshot": {
    "categories": [
      1
    ],
    "content": "<p>2026년 10월 조사 기준. 부모급여와 아동수당은 신청 대상과 절차를 각각 확인해야 합니다.</p>\n<h2>부모급여와 아동수당</h2>\n<p>부모급여는 0~11개월 월 100만원, 12~23개월 월 50만원입니다. [N037]</p>\n<p>아동수당은 9세 미만, 기본 월 10만원입니다. [N038] 지역별 추가 지급과 개인별 신청 조건은 확인하세요.</p>\n<h2>신청 전에 확인할 것</h2>\n<p>어린이집을 이용하면 부모급여의 지급 방식과 차액이 달라질 수 있습니다. 복지로와 거주지 담당 기관에서 현재 대상과 신청 방법을 확인하세요.</p>\n<p>출처: [N037] 보건복지부 부모급여 안내, [N038] 보건복지부 아동수당 안내.</p>",
    "excerpt": "정부 지원을 확인하는 순서",
    "featured_media": 1,
    "slug": "bx-info",
    "status": "draft",
    "tags": [
      1
    ],
    "title": "2026 부모급여·아동수당 한 번에 정리"
  },
  "status": "publish",
  "url": "http://mock.local/?p=1"
}
');
INSERT INTO "posts" VALUES('sponsor','{
  "approval": {
    "date": "2026-10-27",
    "hash": "5213304976ae98acd84fa8970ffba68825c52e6c670182e34702ebc54463c197",
    "reviewed_rules": [
      "health_safety.H1",
      "health_safety.H4",
      "child_privacy.C1",
      "automation.T1"
    ],
    "reviewer": "서윤"
  },
  "auto_allowed_types": [
    "info",
    "play"
  ],
  "config_path": null,
  "content_hash": "5def0a977bd7cf5ea9127cd23b0c6b1fa5314615b3e712aec5090fbccdf57264",
  "daily_limit": 2,
  "date": "2026-10-27",
  "destination": "mock",
  "doc": {
    "as_of": "2026-10-27",
    "author": "서윤(가상)",
    "authoring_path": "사람 작성(가상 시연)",
    "commercial_relations": [
      {
        "brand": "가상 도담",
        "details": "상품 무료제공",
        "kind": "sponsor",
        "program": ""
      }
    ],
    "comparison_only": false,
    "content_id": "sponsor",
    "content_type": "sponsor",
    "contract": {
      "ai_allowed": false
    },
    "description": "가상 협찬의 표시와 사람 경험 시연",
    "emergency_topics": [],
    "experience": "가상 시연: 사람이 실제 사용한 경험을 여기에 직접 작성합니다. 이 문장은 실제 사용 후기가 아닙니다.",
    "experience_by": "human",
    "html": "<p>상품 협찬: 가상 브랜드 도담에서 그림책꽂이를 무료 제공받았습니다.</p>\n<h2>책을 정리할 자리</h2>\n<p>그림책 표지가 보이도록 정리할 수 있는 가상의 원목 꽂이입니다. 설치 전 넘어짐 방지와 제품의 안전 자료를 확인하세요.</p>\n<p>이 글과 브랜드는 가상 시연입니다. 사용 경험은 사람이 직접 적어야 합니다.</p>\n<p>출처: [BX037] 공정거래위원회 추천·보증 표시 안내. 제품과 브랜드는 가상 시연입니다.</p>\n<p>가상 시연: 사람이 실제 사용한 경험을 여기에 직접 작성합니다. 이 문장은 실제 사용 후기가 아닙니다.</p>",
    "markdown": "상품 협찬: 가상 브랜드 도담에서 그림책꽂이를 무료 제공받았습니다.\n\n## 책을 정리할 자리\n\n그림책 표지가 보이도록 정리할 수 있는 가상의 원목 꽂이입니다. 설치 전 넘어짐 방지와 제품의 안전 자료를 확인하세요.\n\n이 글과 브랜드는 가상 시연입니다. 사용 경험은 사람이 직접 적어야 합니다.\n\n출처: [BX037] 공정거래위원회 추천·보증 표시 안내. 제품과 브랜드는 가상 시연입니다.\n\n\n가상 시연: 사람이 실제 사용한 경험을 여기에 직접 작성합니다. 이 문장은 실제 사용 후기가 아닙니다.",
    "media": [
      {
        "alt": "가상 그림책꽂이 그림",
        "child_photo": false,
        "kind": "illustration",
        "path": "samples/books.png",
        "permissions": "직접 제작"
      }
    ],
    "photos": [],
    "product_records": [
      {
        "ad_review_scope": "해당 범위 확인 완료",
        "certification_scheme": "제품 분류 확인 완료",
        "classification_basis": "가상 제품 분류 자료 확인",
        "intended_use": "책 정리",
        "maker": "가상 제작사",
        "model": "가상 A",
        "product_type": "그림책꽂이",
        "recall_check": "해당 모델 확인 완료",
        "recall_status": "none_found",
        "regulated_category": "other"
      }
    ],
    "risk_flags": [
      "commercial"
    ],
    "source_notes": [
      {
        "age_range": "0~3세",
        "checked_on": "2026-10-27",
        "claims": [
          "경제적 이해관계를 표시합니다."
        ],
        "country": "KR",
        "id": "BX037",
        "license": "원문 링크 및 이용 조건 확인",
        "official": true,
        "url": "https://www.law.go.kr/LSW/admRulInfoR.do?admRulSeq=2100000280130&chrClsCd=010201"
      }
    ],
    "title": "도담 그림책꽂이 정리 이야기"
  },
  "draft_hash": "a5acea1ae398c7ff57a857c9f050670a5cd9d660d2347d58028f9502ffbd7668",
  "id": "sponsor",
  "is_update": false,
  "post_id": 2,
  "prepared": {
    "categories": [
      1
    ],
    "destination": "mock",
    "media": [
      2
    ],
    "media_hashes": {
      "2": "746a27c05dab0e1bb948af77314adabc546ab1a3b5171169a1eae0ecd44dcf35"
    },
    "tags": [
      2
    ]
  },
  "server_checked": true,
  "server_date": "2026-10-28T09:00:00",
  "server_history": [
    "future",
    "publish"
  ],
  "server_new_confirmed": true,
  "slug": "bx-sponsor",
  "snapshot": {
    "categories": [
      1
    ],
    "content": "<p>상품 협찬: 가상 브랜드 도담에서 그림책꽂이를 무료 제공받았습니다.</p>\n<h2>책을 정리할 자리</h2>\n<p>그림책 표지가 보이도록 정리할 수 있는 가상의 원목 꽂이입니다. 설치 전 넘어짐 방지와 제품의 안전 자료를 확인하세요.</p>\n<p>이 글과 브랜드는 가상 시연입니다. 사용 경험은 사람이 직접 적어야 합니다.</p>\n<p>출처: [BX037] 공정거래위원회 추천·보증 표시 안내. 제품과 브랜드는 가상 시연입니다.</p>\n<p>가상 시연: 사람이 실제 사용한 경험을 여기에 직접 작성합니다. 이 문장은 실제 사용 후기가 아닙니다.</p>",
    "excerpt": "가상 협찬의 표시와 사람 경험 시연",
    "featured_media": 2,
    "slug": "bx-sponsor",
    "status": "draft",
    "tags": [
      2
    ],
    "title": "도담 그림책꽂이 정리 이야기"
  },
  "sponsor_material": "c26d2c34fd2ca7acabc20b01f4cc3348d1d6ab201963b275ed4a903bac4e6383",
  "status": "publish",
  "url": "http://mock.local/?p=2"
}
');
CREATE TABLE runs (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "runs" VALUES('create:mock:info','{
  "id": "create:mock:info",
  "post_id": 1,
  "state": "done"
}
');
INSERT INTO "runs" VALUES('content:mock:dd337ce63aec07335241de59785d8f0a00b587e7a84aa79e78d41315f9b2c519','{
  "id": "content:mock:dd337ce63aec07335241de59785d8f0a00b587e7a84aa79e78d41315f9b2c519",
  "owner": "info"
}
');
INSERT INTO "runs" VALUES('quota:mock:2026-10-27:info','{
  "date": "2026-10-27",
  "id": "quota:mock:2026-10-27:info",
  "state": "reserved"
}
');
INSERT INTO "runs" VALUES('schedule:mock:1:51f274513fb899e9461d3ad10c53e3e82f476fd438d07121396d8c10e2dd4e4b','{
  "id": "schedule:mock:1:51f274513fb899e9461d3ad10c53e3e82f476fd438d07121396d8c10e2dd4e4b",
  "state": "sending"
}
');
INSERT INTO "runs" VALUES('template-approval:library','{
  "date": "2026-10-27",
  "id": "library",
  "reviewer": "서윤",
  "schema_hash": "7dc96e4a6d7ca447861933c061f51373d279afe2c06f42fa0835d58ea28ab8ab",
  "template_hash": "f856f009fccdacfe9cd2f751242e0735ca93e61d6df553e6e59bbb3f63d2b98e"
}
');
INSERT INTO "runs" VALUES('create:mock:sponsor','{
  "id": "create:mock:sponsor",
  "post_id": 2,
  "state": "done"
}
');
INSERT INTO "runs" VALUES('content:mock:5def0a977bd7cf5ea9127cd23b0c6b1fa5314615b3e712aec5090fbccdf57264','{
  "id": "content:mock:5def0a977bd7cf5ea9127cd23b0c6b1fa5314615b3e712aec5090fbccdf57264",
  "owner": "sponsor"
}
');
INSERT INTO "runs" VALUES('quota:mock:2026-10-27:sponsor','{
  "date": "2026-10-27",
  "id": "quota:mock:2026-10-27:sponsor",
  "state": "reserved"
}
');
INSERT INTO "runs" VALUES('schedule:mock:2:5213304976ae98acd84fa8970ffba68825c52e6c670182e34702ebc54463c197','{
  "id": "schedule:mock:2:5213304976ae98acd84fa8970ffba68825c52e6c670182e34702ebc54463c197",
  "state": "sending"
}
');
CREATE TABLE sponsors (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "sponsors" VALUES('blanket','{
  "content_id": "blanket",
  "history": [
    {
      "date": "2026-10-27",
      "records": {
        "advertiser": "포근담요",
        "channel": "블로그",
        "contact": "가상 연락처",
        "content_id": "blanket",
        "offer": "가상 제품"
      },
      "state": "inquiry"
    },
    {
      "date": "2026-10-27",
      "records": {
        "cost_agreement": "해당 없음",
        "notice": "외부 회신 없음",
        "reason": "영아 수면 안전 충돌",
        "return_terms": "해당 없음"
      },
      "state": "declined"
    }
  ],
  "id": "blanket",
  "state": "declined"
}
');
INSERT INTO "sponsors" VALUES('shelf','{
  "content_id": "sponsor",
  "history": [
    {
      "date": "2026-10-27",
      "records": {
        "advertiser": "도담",
        "channel": "블로그",
        "contact": "가상 연락처",
        "content_id": "sponsor",
        "offer": "가상 제품"
      },
      "state": "inquiry"
    },
    {
      "date": "2026-10-27",
      "records": {
        "ai_allowed": false,
        "child_privacy": "아이 신상·사진 요구 없음",
        "deadline": "2026-11-10",
        "disclosure": "첫 문단 상품 무료제공 표시",
        "product_safety": "가상 A 모델 분류·리콜 확인",
        "rights": "블로그 1회 게시; 2차 이용 별도 동의",
        "settlement": "현금 없음, 현물 가액 별도 확인"
      },
      "state": "reviewing"
    },
    {
      "date": "2026-10-27",
      "records": {
        "agreement": "가상 제안 조건 수락, 실제 회신 없음"
      },
      "state": "accepted"
    },
    {
      "date": "2026-10-27",
      "records": {
        "cancellation": "위험 발견 시 중단",
        "cash": "0원",
        "contract_version": "가상 계약 v1",
        "deadlines": "작성 11월 5일, 확인 11월 8일",
        "goods": "가상 그림책꽂이 1개",
        "payment": "현금 지급 없음",
        "return_terms": "반납 없음",
        "revision_scope": "사실관계 1회",
        "rights": "블로그 게시만"
      },
      "state": "contracted"
    },
    {
      "date": "2026-10-27",
      "records": {
        "condition": "파손 없음(가상)",
        "experience": "가상 사람의 정리 경험 시연",
        "goods_valuation": "가상 제공 명세 확인, 실제 가액 미확정",
        "model": "가상 A",
        "received_date": "2026-10-27"
      },
      "state": "received"
    },
    {
      "date": "2026-10-27",
      "records": {
        "authoring_path": "사람 작성(가상 시연)",
        "disclosure": "첫 문단 상품 무료제공",
        "experience": "가상 사람이 책을 정리한 경험",
        "photos": "직접 만든 그림, 아이 사진 없음",
        "sources": "제품 분류 및 리콜 자료 확인(가상)"
      },
      "state": "writing"
    },
    {
      "date": "2026-10-27",
      "records": {
        "count": 1,
        "feedback": "가상 광고주 사실관계 확인; 외부 회신 없음",
        "version": "가상 초안 v1"
      },
      "state": "brand_review"
    },
    {
      "date": "2026-10-27",
      "records": {
        "content_hash": "5213304976ae98acd84fa8970ffba68825c52e6c670182e34702ebc54463c197",
        "reviewed_at": "2026-10-27",
        "reviewer": "서윤"
      },
      "state": "human_approval"
    },
    {
      "date": "2026-10-27",
      "records": {
        "allowed_at": "2026-10-27",
        "approval_hash": "5213304976ae98acd84fa8970ffba68825c52e6c670182e34702ebc54463c197",
        "destination": "mock"
      },
      "state": "approved"
    },
    {
      "date": "2026-10-27",
      "records": {
        "post_id": 2,
        "scheduled_at": "2026-10-28T09:00:00",
        "server_status": "future",
        "timezone": "Asia/Seoul"
      },
      "state": "scheduled"
    },
    {
      "date": "2026-10-27",
      "records": {
        "contract_hash": "c26d2c34fd2ca7acabc20b01f4cc3348d1d6ab201963b275ed4a903bac4e6383",
        "disclosure": [
          {
            "brand": "가상 도담",
            "details": "상품 무료제공",
            "kind": "sponsor",
            "program": ""
          }
        ],
        "published_at": "2026-10-28T09:00:00",
        "url": "http://mock.local/?p=2"
      },
      "state": "published"
    },
    {
      "date": "2026-10-27",
      "records": {
        "allowed_data": "집계만",
        "metrics_definition": "mock 방문 120·검색 클릭 20",
        "period": "2026-10-01~2026-10-27",
        "privacy_checked": true
      },
      "state": "reported"
    },
    {
      "date": "2026-10-27",
      "records": {
        "cash": 0,
        "goods": "가상 그림책꽂이",
        "invoice": "해당 여부 확인",
        "payment_due": "2026-11-10",
        "return_terms": "반납 없음",
        "withholding": "세무 상담 확인"
      },
      "state": "settlement_pending"
    },
    {
      "date": "2026-10-27",
      "records": {
        "evidence": "가상 제공 명세 v1",
        "expenses": "가상 기록 없음",
        "goods": "가상 그림책꽂이",
        "paid_amount": "0(현금 없음)",
        "paid_at": "2026-10-27",
        "tax_check": "국세청126 확인 과제"
      },
      "state": "settled"
    }
  ],
  "id": "shelf",
  "state": "settled"
}
');
COMMIT;
